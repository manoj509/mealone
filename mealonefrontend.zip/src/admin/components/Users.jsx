import React from "react";

const Users = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Users Page</h1>
      <p>Manage all the users here.</p>
    </div>
  );
};

export default Users;
