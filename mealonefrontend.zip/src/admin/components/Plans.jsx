import React from 'react'

const Plans = () => {
  return (
    <div>Plans</div>
  )
}

export default Plans