import React from 'react'

const DeliveryBoy = () => {
  return (
    <div>DeliveryBoy</div>
  )
}

export default DeliveryBoy