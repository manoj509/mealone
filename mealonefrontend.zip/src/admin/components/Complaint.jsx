import React from 'react'

const Complaint = () => {
  return (
    <div>Complaint</div>
  )
}

export default Complaint